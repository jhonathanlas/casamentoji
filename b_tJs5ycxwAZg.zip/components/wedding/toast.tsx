interface ToastProps {
  message: string
  show: boolean
}

export function Toast({ message, show }: ToastProps) {
  return (
    <div
      className={`
        pointer-events-none fixed bottom-8 left-1/2 z-50 -translate-x-1/2 whitespace-nowrap 
        rounded-full bg-sage-dark px-6 py-3.5 text-sm tracking-wide text-white 
        transition-opacity duration-300
        ${show ? 'opacity-100' : 'opacity-0'}
      `}
    >
      {message}
    </div>
  )
}
