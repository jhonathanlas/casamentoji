'use client'

import { useState, useEffect } from 'react'

export function CountdownSection() {
  const [timeLeft, setTimeLeft] = useState({
    days: 0,
    hours: 0,
    minutes: 0,
    seconds: 0
  })

  useEffect(() => {
    const weddingDate = new Date('2026-05-02T16:00:00')

    const updateCountdown = () => {
      const now = new Date()
      let diff = weddingDate.getTime() - now.getTime()

      if (diff < 0) {
        setTimeLeft({ days: 0, hours: 0, minutes: 0, seconds: 0 })
        return
      }

      const days = Math.floor(diff / 86400000)
      diff -= days * 86400000
      const hours = Math.floor(diff / 3600000)
      diff -= hours * 3600000
      const minutes = Math.floor(diff / 60000)
      diff -= minutes * 60000
      const seconds = Math.floor(diff / 1000)

      setTimeLeft({ days, hours, minutes, seconds })
    }

    updateCountdown()
    const interval = setInterval(updateCountdown, 1000)
    return () => clearInterval(interval)
  }, [])

  return (
    <div className="bg-navy px-6 py-5 text-center">
      <p className="mb-3 text-xs uppercase tracking-[0.2em] text-white/50">
        Contagem regressiva para o grande dia
      </p>
      
      <div className="flex justify-center gap-4">
        <CountdownItem value={timeLeft.days} label="Dias" />
        <CountdownItem value={timeLeft.hours} label="Horas" padZero />
        <CountdownItem value={timeLeft.minutes} label="Min" padZero />
        <CountdownItem value={timeLeft.seconds} label="Seg" padZero />
      </div>
    </div>
  )
}

function CountdownItem({ 
  value, 
  label, 
  padZero = false 
}: { 
  value: number
  label: string
  padZero?: boolean 
}) {
  const displayValue = padZero ? String(value).padStart(2, '0') : value

  return (
    <div className="text-center">
      <div className="flex h-13 w-14 items-center justify-center rounded-lg border border-white/10 bg-white/[0.08] font-serif text-2xl font-medium text-white">
        {displayValue}
      </div>
      <div className="mt-1.5 text-[10px] uppercase tracking-widest text-white/40">
        {label}
      </div>
    </div>
  )
}
