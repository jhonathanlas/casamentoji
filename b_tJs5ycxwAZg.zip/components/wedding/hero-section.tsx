export function HeroSection() {
  return (
    <section className="relative overflow-hidden bg-gradient-to-br from-sage-dark via-sage to-sage-light px-6 py-16 text-center">
      {/* Pattern overlay */}
      <div 
        className="absolute inset-0 opacity-[0.04]"
        style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='1'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`
        }}
      />
      
      <div className="relative z-10">
        <p className="mb-4 font-serif italic text-lg tracking-widest text-white/70">
          I & J
        </p>
        
        <h1 className="mb-2 font-serif text-5xl font-normal leading-tight text-white">
          Ilan
          <span className="block italic">& Jhonathan</span>
        </h1>
        
        <p className="mb-5 text-sm uppercase tracking-[0.3em] text-white/65">
          02 · 05 · 2026
        </p>
        
        <div className="my-5 flex items-center justify-center gap-3">
          <span className="h-px w-16 bg-white/35" />
          <span className="text-lg text-gold">&#10022;</span>
          <span className="h-px w-16 bg-white/35" />
        </div>
        
        <p className="text-sm font-light leading-relaxed tracking-wide text-white/75">
          Compartilhe os momentos mais especiais
          <br />
          do nosso grande dia
        </p>
      </div>
    </section>
  )
}
